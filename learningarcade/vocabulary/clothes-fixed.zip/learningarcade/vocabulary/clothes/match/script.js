(function () {
  "use strict";
  const ITEMS = [
    { id: "sweater", word: "sweater", img: "../images/sweater.png", audio: "../audio/sweater.mp3" },
    { id: "t-shirt", word: "T-shirt", img: "../images/t-shirt.png", audio: "../audio/t-shirt.mp3" },
    { id: "shirt", word: "shirt", img: "../images/shirt.png", audio: "../audio/shirt.mp3" },
    { id: "pants", word: "pants", img: "../images/pants.png", audio: "../audio/pants.mp3" },
    { id: "jeans", word: "jeans", img: "../images/jeans.png", audio: "../audio/jeans.mp3" },
    { id: "shorts", word: "shorts", img: "../images/shorts.png", audio: "../audio/shorts.mp3" },
    { id: "suit", word: "suit", img: "../images/suit.png", audio: "../audio/suit.mp3" },
    { id: "dress", word: "dress", img: "../images/dress.png", audio: "../audio/dress.mp3" },
    { id: "skirt", word: "skirt", img: "../images/skirt.png", audio: "../audio/skirt.mp3" },
    { id: "coat", word: "coat", img: "../images/coat.png", audio: "../audio/coat.mp3" },
    { id: "jacket", word: "jacket", img: "../images/jacket.png", audio: "../audio/jacket.mp3" },
    { id: "socks", word: "socks", img: "../images/socks.png", audio: "../audio/socks.mp3" },
    { id: "sneakers", word: "sneakers", img: "../images/sneakers.png", audio: "../audio/sneakers.mp3" },
    { id: "shoes", word: "shoes", img: "../images/shoes.png", audio: "../audio/shoes.mp3" },
    { id: "hat", word: "hat", img: "../images/hat.png", audio: "../audio/hat.mp3" },
    { id: "cap", word: "cap", img: "../images/cap.png", audio: "../audio/cap.mp3" },
  ];
  const PAIR_COUNT = 6;
  const GAME_ID = "vocab-clothes-match";
  const MODE_LABELS = ["Picture → Word", "Audio → Word", "Audio → Picture"];
  const $ = (id) => document.getElementById(id);

  let mode = 0;
  let rounds = [];
  let roundIndex = 0;
  let score = 0;
  let correctPairs = 0;
  let attempts = 0;
  let selectedLeft = null;
  let selectedRight = null;
  let matches = {};
  let locked = false;
  let currentAudio = null;

  const pairsGrid = $("pairsGrid");
  const feedback = $("feedback");
  const instruction = $("instruction");

  function shuffle(a) {
    a = a.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }
  function show(s) {
    $("startScreen").hidden = s !== "start";
    $("gameScreen").hidden = s !== "game";
    $("endScreen").hidden = s !== "end";
  }
  function setFb(msg, type) {
    feedback.textContent = msg || "";
    feedback.className = "feedback" + (type ? " " + type : "");
  }
  function stopAudio() {
    if (currentAudio) {
      try { currentAudio.pause(); currentAudio.currentTime = 0; } catch (e) {}
      currentAudio = null;
    }
  }
  function playSrc(src) {
    stopAudio();
    const a = new Audio(src);
    currentAudio = a;
    a.play().catch(() => {});
    a.onended = () => { if (currentAudio === a) currentAudio = null; };
  }

  document.querySelectorAll(".mode-tab").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".mode-tab").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      mode = Number(btn.dataset.mode);
    });
  });

  function leftContent(item) {
    if (mode === 0) {
      return { html: `<img src="${item.img}" alt="">`, isAudio: false };
    }
    return {
      html: `<span aria-hidden="true">🔊</span><span style="font-size:.8rem;color:var(--muted)">Play</span>`,
      isAudio: true,
      src: item.audio,
    };
  }
  function rightContent(item) {
    if (mode === 2) {
      return { html: `<img src="${item.img}" alt="">` };
    }
    return { html: item.word };
  }

  function renderRound() {
    locked = false;
    selectedLeft = null;
    selectedRight = null;
    matches = {};
    stopAudio();
    setFb("", "");
    instruction.textContent = "Tap one, then its match";
    $("promptText").textContent = MODE_LABELS[mode];

    const items = rounds[roundIndex];
    const leftOrder = shuffle(items);
    const rightOrder = shuffle(items);
    pairsGrid.innerHTML = "";

    leftOrder.forEach((item) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "pair-btn";
      btn.dataset.id = item.id;
      btn.dataset.side = "left";
      const lc = leftContent(item);
      if (lc.isAudio) btn.classList.add("audio-side");
      btn.innerHTML = lc.html;
      btn.addEventListener("click", () => {
        if (lc.isAudio) playSrc(lc.src);
        onTap(btn, "left");
      });
      pairsGrid.appendChild(btn);
    });
    rightOrder.forEach((item) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "pair-btn";
      btn.dataset.id = item.id;
      btn.dataset.side = "right";
      btn.innerHTML = rightContent(item).html;
      btn.addEventListener("click", () => onTap(btn, "right"));
      pairsGrid.appendChild(btn);
    });
    // interleave display: left0, right0, left1, right1... currently we appended all left then all right
    // Rebuild in column order L R L R
    const leftBtns = [...pairsGrid.querySelectorAll('[data-side="left"]')];
    const rightBtns = [...pairsGrid.querySelectorAll('[data-side="right"]')];
    pairsGrid.innerHTML = "";
    for (let i = 0; i < PAIR_COUNT; i++) {
      pairsGrid.appendChild(leftBtns[i]);
      pairsGrid.appendChild(rightBtns[i]);
    }

    updateStats();
  }

  function onTap(btn, side) {
    if (locked || btn.classList.contains("matched")) return;
    if (side === "left") {
      pairsGrid.querySelectorAll('[data-side="left"]:not(.matched)').forEach((b) => b.classList.remove("selected"));
      btn.classList.add("selected");
      selectedLeft = btn.dataset.id;
    } else {
      pairsGrid.querySelectorAll('[data-side="right"]:not(.matched)').forEach((b) => b.classList.remove("selected"));
      btn.classList.add("selected");
      selectedRight = btn.dataset.id;
    }
    if (selectedLeft && selectedRight) resolve();
  }

  function resolve() {
    locked = true;
    attempts++;
    const ok = selectedLeft === selectedRight;
    const L = selectedLeft;
    const R = selectedRight;
    if (ok) {
      correctPairs++;
      score += 100;
      pairsGrid.querySelectorAll(".pair-btn").forEach((b) => {
        if (b.dataset.id === L || b.dataset.id === R) {
          b.classList.remove("selected");
          b.classList.add("matched");
        }
      });
      matches[L] = true;
      setFb("Correct!", "ok");
      selectedLeft = selectedRight = null;
      updateStats();
      if (Object.keys(matches).length >= PAIR_COUNT) {
        setTimeout(() => nextRound(), 650);
      } else {
        setTimeout(() => {
          locked = false;
          setFb("", "");
        }, 350);
      }
    } else {
      pairsGrid.querySelectorAll(".pair-btn").forEach((b) => {
        if (
          (b.dataset.side === "left" && b.dataset.id === L) ||
          (b.dataset.side === "right" && b.dataset.id === R)
        ) {
          b.classList.remove("selected");
          b.classList.add("wrong");
        }
      });
      setFb("Not a match", "bad");
      selectedLeft = selectedRight = null;
      setTimeout(() => {
        pairsGrid.querySelectorAll(".wrong").forEach((b) => b.classList.remove("wrong"));
        locked = false;
        setFb("", "");
      }, 500);
    }
  }

  function updateStats() {
    $("roundText").textContent = roundIndex + 1 + " / " + rounds.length;
    $("scoreText").textContent = String(score);
    $("matchedText").textContent = Object.keys(matches).length + " / " + PAIR_COUNT;
  }

  function nextRound() {
    roundIndex++;
    if (roundIndex >= rounds.length) finish();
    else {
      locked = false;
      renderRound();
    }
  }

  function finish() {
    stopAudio();
    const acc = attempts ? Math.round((correctPairs / attempts) * 100) : 0;
    $("finalScore").textContent = String(score);
    $("finalAccuracy").textContent = acc + "%";
    $("finalRounds").textContent = String(rounds.length);
    $("endTitle").textContent = acc === 100 ? "Perfect!" : acc >= 70 ? "Great job!" : "Good practice!";
    $("endSummary").textContent = "Mode: " + MODE_LABELS[mode] + " · " + correctPairs + " matches in " + attempts + " tries.";
    try {
      if (window.LAStars) {
        LAStars.recordPlay(GAME_ID);
        LAStars.saveFromAccuracy(GAME_ID, acc);
        LAStars.apply($("endScreen"));
      }
    } catch (e) {}
    const stars = acc >= 90 ? 3 : acc >= 70 ? 2 : acc >= 40 ? 1 : 0;
    $("endScreen").querySelectorAll(".star").forEach((el) => {
      const n = Number(el.getAttribute("data-n") || 0);
      el.classList.toggle("is-filled", n <= stars);
      el.textContent = n <= stars ? "★" : "☆";
    });
    show("end");
  }

  function startGame() {
    const shuffled = shuffle(ITEMS);
    rounds = [];
    for (let i = 0; i < shuffled.length; i += PAIR_COUNT) {
      rounds.push(shuffled.slice(i, i + PAIR_COUNT));
    }
    // if last round short, still play
    rounds = rounds.filter((r) => r.length >= 4);
    if (!rounds.length) rounds = [shuffled.slice(0, PAIR_COUNT)];
    roundIndex = 0;
    score = 0;
    correctPairs = 0;
    attempts = 0;
    show("game");
    renderRound();
  }

  function applyTheme(dark) {
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
    document.body.classList.toggle("dark-mode", dark);
    $("themeBtn").textContent = dark ? "☀️" : "🌙";
    try { localStorage.setItem("clothes-theme", dark ? "dark" : "light"); } catch (e) {}
  }
  $("themeBtn").addEventListener("click", () =>
    applyTheme(document.documentElement.getAttribute("data-theme") !== "dark")
  );
  try { applyTheme(localStorage.getItem("clothes-theme") === "dark"); } catch (e) { applyTheme(false); }

  $("startBtn").addEventListener("click", startGame);
  $("playAgainBtn").addEventListener("click", startGame);
})();
