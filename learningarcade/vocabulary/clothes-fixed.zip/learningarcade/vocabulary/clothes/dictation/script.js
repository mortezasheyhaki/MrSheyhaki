(function () {
  "use strict";
  const ITEMS = [
    { id: "sweater", answers: ["sweater"], img: "../images/sweater.png", audio: "../audio/sweater.mp3" },
    { id: "t-shirt", answers: ["t-shirt", "tshirt", "t shirt"], img: "../images/t-shirt.png", audio: "../audio/t-shirt.mp3" },
    { id: "shirt", answers: ["shirt"], img: "../images/shirt.png", audio: "../audio/shirt.mp3" },
    { id: "pants", answers: ["pants", "trousers"], img: "../images/pants.png", audio: "../audio/pants.mp3" },
    { id: "jeans", answers: ["jeans"], img: "../images/jeans.png", audio: "../audio/jeans.mp3" },
    { id: "shorts", answers: ["shorts"], img: "../images/shorts.png", audio: "../audio/shorts.mp3" },
    { id: "suit", answers: ["suit"], img: "../images/suit.png", audio: "../audio/suit.mp3" },
    { id: "dress", answers: ["dress"], img: "../images/dress.png", audio: "../audio/dress.mp3" },
    { id: "skirt", answers: ["skirt"], img: "../images/skirt.png", audio: "../audio/skirt.mp3" },
    { id: "coat", answers: ["coat"], img: "../images/coat.png", audio: "../audio/coat.mp3" },
    { id: "jacket", answers: ["jacket"], img: "../images/jacket.png", audio: "../audio/jacket.mp3" },
    { id: "socks", answers: ["socks", "sock"], img: "../images/socks.png", audio: "../audio/socks.mp3" },
    { id: "sneakers", answers: ["sneakers", "trainers"], img: "../images/sneakers.png", audio: "../audio/sneakers.mp3" },
    { id: "shoes", answers: ["shoes", "shoe"], img: "../images/shoes.png", audio: "../audio/shoes.mp3" },
    { id: "hat", answers: ["hat"], img: "../images/hat.png", audio: "../audio/hat.mp3" },
    { id: "cap", answers: ["cap"], img: "../images/cap.png", audio: "../audio/cap.mp3" },
  ];
  const GAME_ID = "vocab-clothes-dictation";
  const $ = (id) => document.getElementById(id);

  let order = [];
  let idx = 0;
  let score = 0;
  let correct = 0;
  let attempts = 0;
  let locked = false;
  let currentAudio = null;

  function shuffle(a) {
    a = a.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }
  function norm(s) {
    return String(s || "").toLowerCase().replace(/[’']/g, "'").replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, " ").trim();
  }
  function show(s) {
    $("startScreen").hidden = s !== "start";
    $("gameScreen").hidden = s !== "game";
    $("endScreen").hidden = s !== "end";
  }
  function setFb(msg, type) {
    $("feedback").textContent = msg || "";
    $("feedback").className = "feedback" + (type ? " " + type : "");
  }
  function playSrc(src) {
    if (currentAudio) {
      try { currentAudio.pause(); } catch (e) {}
    }
    const a = new Audio(src);
    currentAudio = a;
    a.play().catch(() => {});
  }

  function render() {
    locked = false;
    const item = ITEMS[order[idx]];
    $("sceneImg").src = item.img;
    $("sceneImg").alt = item.id;
    $("typeInput").value = "";
    $("typeInput").classList.remove("wrong", "correct");
    $("checkBtn").disabled = true;
    setFb("", "");
    $("itemText").textContent = idx + 1 + " / " + order.length;
    $("scoreText").textContent = String(score);
    $("correctText").textContent = String(correct);
    setTimeout(() => $("typeInput").focus(), 50);
  }

  function check() {
    if (locked) return;
    const item = ITEMS[order[idx]];
    const user = norm($("typeInput").value);
    if (!user) return;
    locked = true;
    attempts++;
    $("checkBtn").disabled = true;
    const ok = item.answers.some((a) => norm(a) === user);
    if (ok) {
      correct++;
      score += 100;
      setFb("Correct!", "ok");
      $("typeInput").classList.add("correct");
      $("scoreText").textContent = String(score);
      $("correctText").textContent = String(correct);
      setTimeout(() => {
        idx++;
        if (idx >= order.length) finish();
        else render();
      }, 700);
    } else {
      setFb("Try again — or tap 🔊", "bad");
      $("typeInput").classList.add("wrong");
      setTimeout(() => {
        locked = false;
        $("typeInput").classList.remove("wrong");
        $("checkBtn").disabled = !$("typeInput").value.trim();
        $("typeInput").select();
        setFb("", "");
      }, 700);
    }
  }

  function finish() {
    const acc = attempts ? Math.round((correct / attempts) * 100) : 0;
    $("finalScore").textContent = String(score);
    $("finalAccuracy").textContent = acc + "%";
    $("finalWords").textContent = String(order.length);
    $("endTitle").textContent = acc === 100 ? "Perfect!" : acc >= 70 ? "Great job!" : "Good practice!";
    $("endSummary").textContent = correct + " of " + order.length + " words correct.";
    try {
      if (window.LAStars) {
        LAStars.recordPlay(GAME_ID);
        LAStars.saveFromAccuracy(GAME_ID, acc);
        LAStars.apply($("endScreen"));
      }
    } catch (e) {}
    const stars = acc >= 90 ? 3 : acc >= 70 ? 2 : acc >= 40 ? 1 : 0;
    $("endScreen").querySelectorAll(".star").forEach((el) => {
      const n = Number(el.getAttribute("data-n") || 0);
      el.classList.toggle("is-filled", n <= stars);
      el.textContent = n <= stars ? "★" : "☆";
    });
    show("end");
  }

  function start() {
    order = shuffle(ITEMS.map((_, i) => i));
    idx = 0;
    score = 0;
    correct = 0;
    attempts = 0;
    show("game");
    render();
  }

  function applyTheme(dark) {
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
    document.body.classList.toggle("dark-mode", dark);
    $("themeBtn").textContent = dark ? "☀️" : "🌙";
    try { localStorage.setItem("clothes-theme", dark ? "dark" : "light"); } catch (e) {}
  }
  $("themeBtn").addEventListener("click", () =>
    applyTheme(document.documentElement.getAttribute("data-theme") !== "dark")
  );
  try { applyTheme(localStorage.getItem("clothes-theme") === "dark"); } catch (e) { applyTheme(false); }

  $("startBtn").addEventListener("click", start);
  $("playAgainBtn").addEventListener("click", start);
  $("checkBtn").addEventListener("click", check);
  $("playAudioBtn").addEventListener("click", () => playSrc(ITEMS[order[idx]].audio));
  $("typeInput").addEventListener("input", () => {
    if (!locked) $("checkBtn").disabled = !$("typeInput").value.trim();
  });
  $("typeInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !$("checkBtn").disabled && !locked) {
      e.preventDefault();
      check();
    }
  });
})();
