/* ===== Arcade FX: progress bar, combo, milestone celebration ===== */
(function () {
  if (window.ArcadeFX) return;
  var streak = 0, best = 0, count = 0, lastPct = 0, ctx = null;
  var CHEERS = [["🌟","Awesome!","10 correct answers!"],["🚀","Superstar!","20 correct — unstoppable!"],["👑","Legend!","30 correct — the best of the best!"]];
  function tone(f, d, type, v, when) {
    try {
      if (!ctx) { var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return; ctx = new AC(); }
      if (ctx.state === "suspended") ctx.resume();
      var t = ctx.currentTime + (when || 0), o = ctx.createOscillator(), g = ctx.createGain();
      o.type = type || "sine"; o.frequency.value = f;
      g.gain.setValueAtTime(v || 0.09, t); g.gain.exponentialRampToValueAtTime(0.001, t + d);
      o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + d + 0.03);
    } catch (e) {}
  }
  function label(n) { return n >= 10 ? "UNSTOPPABLE" : n >= 7 ? "ON FIRE" : n >= 5 ? "HOT STREAK" : n >= 3 ? "NICE" : ""; }
  function chip() {
    var el = document.getElementById("afx-combo");
    if (!el) { el = document.createElement("div"); el.id = "afx-combo"; el.className = "afx-combo"; document.body.appendChild(el); }
    return el;
  }
  function place(el) {
    el = el || document.getElementById("afx-combo");
    var app = (document.getElementById("game-app") || document.getElementById("app"));
    if (!el || !app) return;
    var a = app.querySelector(".afx-bar") || app.querySelector("header") || app.firstElementChild;
    if (!a) return;
    if (a.offsetParent === null) a = app;
    var r = a.getBoundingClientRect();
    el.style.right = Math.max(8, document.documentElement.clientWidth - r.right) + "px";
    el.style.top = Math.max(8, a === app ? r.top + 64 : r.bottom + 8) + "px";
  }
  function showCombo() {
    var el = chip(); place(el);
    el.className = "afx-combo is-on" + (streak >= 5 ? " is-hot" : "");
    el.innerHTML = '<span class="afx-fire">🔥</span> x' + streak + " <em>" + label(streak) + "</em>";
    void el.offsetWidth; el.classList.add("is-bump");
  }
  function celebrate(n) { burst(CHEERS[Math.min(Math.floor(n / 10) - 1, 2)]); }
  function burst(c) {
    [523, 659, 784, 1047, 1319].forEach(function (f, i) { tone(f, 0.22, "triangle", 0.1, i * 0.09); });
    tone(1568, 0.6, "sine", 0.08, 0.5);
    var ov = document.createElement("div"); ov.className = "afx-burst";
    var cols = ["#f59e0b", "#ec4899", "#8b5cf6", "#22c55e", "#3b82f6", "#ef4444"], h = "";
    for (var i = 0; i < 44; i++) h += '<i style="left:' + Math.random() * 100 + "%;background:" + cols[i % 6] + ";animation-delay:" + (Math.random() * 0.35).toFixed(2) + "s;animation-duration:" + (1.3 + Math.random() * 0.9).toFixed(2) + 's"></i>';
    ov.innerHTML = h + '<div class="afx-card"><div class="afx-emoji">' + c[0] + '</div><div class="afx-title">' + c[1] + '</div><div class="afx-sub">' + c[2] + "</div></div>";
    document.body.appendChild(ov);
    setTimeout(function () { ov.classList.add("is-out"); }, 1900);
    setTimeout(function () { if (ov.parentNode) ov.parentNode.removeChild(ov); }, 2300);
  }
  function hookRestart() {
    var L = window.LAFinish;
    if (L && L.startTimer && !L.__afx) { var st = L.startTimer; L.__afx = 1; L.startTimer = function () { api.reset(); return st.apply(this, arguments); }; }
  }
  var api = window.ArcadeFX = {
    ok: function () {
      var nw = Date.now(); if (nw - (api._o || 0) < 90) return; api._o = nw;
      hookRestart(); streak++; count++; if (streak > best) best = streak;
      if (streak >= 2) { var b = 660 * Math.pow(1.0595, Math.min(streak, 12)); tone(b, 0.09, "triangle", 0.08, 0); tone(b * 1.5, 0.14, "triangle", 0.07, 0.07); showCombo(); }
      if (count % 10 === 0 && !api.noMilestone) setTimeout(function () { celebrate(count); }, 250);
    },
    bad: function () {
      var nw = Date.now(); if (nw - (api._b || 0) < 90) return; api._b = nw;
      hookRestart();
      if (streak >= 3) { tone(300, 0.12, "sawtooth", 0.05, 0); tone(200, 0.2, "sawtooth", 0.05, 0.09); }
      if (streak >= 2) { var el = chip(); el.className = "afx-combo is-lost"; el.textContent = "Combo lost"; setTimeout(function () { el.className = "afx-combo"; }, 1200); }
      streak = 0;
    },
    cheer: function (i, n, sub) {
      var T = [["🎉", "Great job!"], ["🌟", "Brilliant!"], ["🏆", "Champion!"]];
      var c = T[i >= n - 1 && n > 1 ? 2 : Math.min(i, 1)];
      burst([c[0], c[1], sub || ("Part " + (i + 1) + " of " + n + " complete")]);
    },
    reset: function () { streak = 0; best = 0; count = 0; lastPct = 0; var el = document.getElementById("afx-combo"); if (el) el.className = "afx-combo"; }
  };
  function sync() {
    var app = (document.getElementById("game-app") || document.getElementById("app")); if (!app) return;
    place();
    var bar = app.querySelector(".afx-bar");
    if (bar && bar.offsetParent === null) { bar.parentNode.removeChild(bar); bar = null; }
    var badge = null, hasBar = false, els = app.querySelectorAll('[class*="-badge"],[class*="-progress"]');
    for (var i = 0; i < els.length; i++) {
      var t = els[i].textContent.trim(); if (els[i].offsetParent === null) continue;
      if (/^\d+\s*\/\s*\d+$/.test(t)) { if (!badge) badge = els[i]; }
      else if (!t && /progress/.test(els[i].className) && !els[i].classList.contains("afx-bar")) hasBar = true;
    }
    if (!badge || hasBar) return;
    var m = badge.textContent.trim().match(/^(\d+)\s*\/\s*(\d+)$/), pct = Math.min(100, Math.round(m[1] / m[2] * 100));
    if (!bar) {
      var host = badge.closest("header") || badge.parentElement;
      bar = document.createElement("div"); bar.className = "afx-bar"; bar.innerHTML = '<i style="width:' + lastPct + '%"></i>';
      host.parentNode.insertBefore(bar, host.nextSibling);
    }
    var fill = bar.firstChild; lastPct = pct;
    requestAnimationFrame(function () { requestAnimationFrame(function () { fill.style.width = pct + "%"; }); });
  }
  var q = 0;
  function start() {
    var app = (document.getElementById("game-app") || document.getElementById("app")); if (!app) return;
    new MutationObserver(function () { if (q) return; q = requestAnimationFrame(function () { q = 0; sync(); }); }).observe(app, { childList: true, subtree: true, characterData: true });
    window.addEventListener("resize", function () { place(); });
    window.addEventListener("scroll", function () { place(); }, { passive: true });
    sync();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
window.ArcadeFX && (ArcadeFX.noMilestone = true);

/* Food Match – 3 modes × 4 sets (5+5+6+6) – AEF Starter Unit 5A */
(function () {
  "use strict";

  

/* === Shared UI sound effects (Web Audio) === */
(function () {
  if (window.__laUiSfx) return;
  var ctx = null;
  function getCtx() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === "suspended") ctx.resume().catch(function () {});
    return ctx;
  }
  function tone(freq, dur, type, vol, when) {
    var c = getCtx();
    if (!c) return;
    var t0 = (when || 0) + c.currentTime;
    var osc = c.createOscillator();
    var gain = c.createGain();
    osc.type = type || "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(vol || 0.12, t0);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    osc.connect(gain);
    gain.connect(c.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }
  function sfxTap() { tone(520, 0.06, "triangle", 0.08); }
  function sfxCorrect() { window.ArcadeFX && ArcadeFX.ok();
    tone(523, 0.1, "sine", 0.12, 0);
    tone(659, 0.12, "sine", 0.12, 0.08);
    tone(784, 0.18, "sine", 0.1, 0.16);
  }
  function sfxWrong() { window.ArcadeFX && ArcadeFX.bad();
    tone(220, 0.14, "sawtooth", 0.07, 0);
    tone(180, 0.18, "sawtooth", 0.06, 0.1);
  }
  function sfxCelebrate() {
    [523, 659, 784, 1047].forEach(function (f, i) { tone(f, 0.15, "sine", 0.1, i * 0.07); });
  }
  window.__laUiSfx = { tap: sfxTap, correct: sfxCorrect, wrong: sfxWrong, celebrate: sfxCelebrate };
  window.sfxTap = sfxTap; window.sfxCorrect = sfxCorrect; window.sfxWrong = sfxWrong; window.sfxCelebrate = sfxCelebrate;
  var lastAt = 0, lastKind = "";
  function fire(kind, fn) {
    var now = Date.now();
    if (kind === lastKind && now - lastAt < 80) return;
    lastKind = kind; lastAt = now;
    try { fn(); } catch (e) {}
  }
  try {
    var origAdd = DOMTokenList.prototype.add;
    DOMTokenList.prototype.add = function () {
      var tokens = Array.prototype.slice.call(arguments);
      var r = origAdd.apply(this, tokens);
      if (tokens.indexOf("correct") >= 0 || tokens.indexOf("is-correct") >= 0 || tokens.indexOf("picked-ok") >= 0) fire("correct", sfxCorrect);
      else if (tokens.indexOf("wrong") >= 0 || tokens.indexOf("is-wrong") >= 0) fire("wrong", sfxWrong);
      return r;
    };
  } catch (e) {}
})();

var GAME_ID = "starter-5a-food-match";
  var CDN = "https://cdn.imgurl.ir/uploads/";

  var ITEMS = [
    { id: "orange-juice", label: "orange juice", image: CDN + "y474569_orange_juicve.png", audio: CDN + "m430952_orange_juice.mp3" },
    { id: "water", label: "water", image: CDN + "l28997_water.png", audio: CDN + "n0647_water_2.mp3" },
    { id: "milk", label: "milk", image: CDN + "o371209_milk.png", audio: CDN + "u575098_milk.mp3" },
    { id: "tea", label: "tea", image: CDN + "m857428_tea.png", audio: CDN + "i64279_tea.mp3" },
    { id: "coffee", label: "coffee", image: CDN + "d27147_coffee.png", audio: CDN + "p495679_coffee_2.mp3" },
    { id: "chocolate", label: "chocolate", image: CDN + "y725106_chocolate.png", audio: CDN + "d5050_chocolate.mp3" },
    { id: "cereal", label: "cereal", image: CDN + "w365421_cereal.png", audio: CDN + "i58138_cereal.mp3" },
    { id: "sandwich", label: "a sandwich", image: CDN + "g593040_a_sandwich.png", audio: CDN + "d503380_a_sandwich.mp3" },
    { id: "sugar", label: "sugar", image: CDN + "t65307_sugar.png", audio: CDN + "i330159_sugar.mp3" },
    { id: "cheese", label: "cheese", image: CDN + "186291_cheese.png", audio: CDN + "s1383_cheese.mp3" },
    { id: "butter", label: "butter", image: CDN + "q390114_butter.png", audio: CDN + "z611617_butter.mp3" },
    { id: "bread", label: "bread", image: CDN + "q54444_bread.png", audio: CDN + "l534951_bread.mp3" },
    { id: "fruit", label: "fruit", image: CDN + "g252280_fruit.png", audio: CDN + "l707897_fruit.mp3" },
    { id: "salad", label: "salad", image: CDN + "r6371_salad.png", audio: CDN + "p30139_salad.mp3" },
    { id: "potatoes", label: "potatoes", image: CDN + "w96375_potatoes.png", audio: CDN + "g067013_potatoes.mp3" },
    { id: "vegetables", label: "vegetables", image: CDN + "j10452_vegetables.png", audio: CDN + "n05883_vegetables_2.mp3" },
    { id: "yogurt", label: "yogurt", image: CDN + "b8972_yogurt.png", audio: CDN + "t99484_yogurt.mp3" },
    { id: "eggs", label: "eggs", image: CDN + "n773101_eggs.png", audio: CDN + "n595148_eggs.mp3" },
    { id: "rice", label: "rice", image: CDN + "y840090_rice.png", audio: CDN + "y43521_rice.mp3" },
    { id: "pasta", label: "pasta", image: CDN + "r41660_pasta.png", audio: CDN + "a446167_pasta.mp3" },
    { id: "meat", label: "meat", image: CDN + "x930201_m.png", audio: CDN + "d13610_m.mp3" },
    { id: "fish", label: "fish", image: CDN + "z779185_fish.png", audio: CDN + "i64676_fish.mp3" }
  ];

  // 2 sets of 5 + 2 sets of 6 = 22
  var SETS = [
    ["orange-juice", "water", "milk", "tea", "coffee"],
    ["chocolate", "cereal", "sandwich", "sugar", "cheese"],
    ["butter", "bread", "fruit", "salad", "potatoes", "vegetables"],
    ["yogurt", "eggs", "rice", "pasta", "meat", "fish"]
  ];

  var MODES = [
    {
      id: "word-pic",
      title: "Words → Pictures",
      left: "word",
      right: "picture",
      tip: "Tap a word, then the matching picture."
    },
    {
      id: "audio-word",
      title: "Audio → Words",
      left: "audio",
      right: "word",
      tip: "Listen, then tap the matching word."
    },
    {
      id: "audio-pic",
      title: "Audio → Pictures",
      left: "audio",
      right: "picture",
      tip: "Listen, then tap the matching picture."
    }
  ];

  var app = document.getElementById("game-app");
  if (!app) return;

  var phase = "menu"; // menu | play | done
  var modeIndex = 0;
  var setIndex = 0;
  var leftOrder = [];
  var rightOrder = [];
  var selectedLeft = null;
  var locked = {}; // leftIndex -> rightId
  var matches = {};
  var modeCorrect = 0;
  var lives = 3;
  var wrongCount = 0; // wrong matches, used for accuracy stars
  var promptAudio = null;
  var matchAudio = null; // never cut on set change
  var busy = false;
  var sfxCtx = null;

  function byId(id) {
    for (var i = 0; i < ITEMS.length; i++) if (ITEMS[i].id === id) return ITEMS[i];
    return null;
  }

  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i];
      a[i] = a[j];
      a[j] = t;
    }
    return a;
  }

  function setSize() {
    return SETS[setIndex] ? SETS[setIndex].length : 5;
  }

  function totalPairs() {
    var n = 0;
    for (var i = 0; i < SETS.length; i++) n += SETS[i].length;
    return n;
  }

  function correctCount() {
    return Object.keys(locked).length;
  }

  function allMatched() {
    return correctCount() >= setSize();
  }

  function getSfxCtx() {
    if (!sfxCtx) {
      try {
        sfxCtx = new (window.AudioContext || window.webkitAudioContext)();
      } catch (e) {
        return null;
      }
    }
    if (sfxCtx.state === "suspended") sfxCtx.resume().catch(function () {});
    return sfxCtx;
  }

  function tone(freq, start, dur, type, gain) {
    var ctx = getSfxCtx();
    if (!ctx) return;
    var o = ctx.createOscillator();
    var g = ctx.createGain();
    o.type = type || "sine";
    o.frequency.setValueAtTime(freq, start);
    g.gain.setValueAtTime(0.0001, start);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, gain || 0.1), start + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    o.connect(g);
    g.connect(ctx.destination);
    o.start(start);
    o.stop(start + dur + 0.02);
  }

  function sfxOk() { window.ArcadeFX && ArcadeFX.ok();
    try {
      if (window.LASfx && LASfx.correct) LASfx.correct();
    } catch (_) {}
    var ctx = getSfxCtx();
    if (!ctx) return;
    var t = ctx.currentTime;
    tone(523.25, t, 0.09, "triangle", 0.11);
    tone(659.25, t + 0.07, 0.1, "triangle", 0.11);
    tone(783.99, t + 0.14, 0.14, "sine", 0.1);
  }

  function sfxBad() { window.ArcadeFX && ArcadeFX.bad();
    try {
      if (window.LASfx && LASfx.wrong) LASfx.wrong();
    } catch (_) {}
    var ctx = getSfxCtx();
    if (!ctx) return;
    tone(200, ctx.currentTime, 0.12, "sawtooth", 0.06);
  }

  function stopPromptAudio() {
    if (promptAudio) {
      try {
        promptAudio.pause();
      } catch (_) {}
      promptAudio = null;
    }
    app.querySelectorAll(".mc-play.playing").forEach(function (b) {
      b.classList.remove("playing");
    });
  }

  // Match audio is allowed to finish even when the next set loads
  function playMatchAudio(src) {
    if (!src) return;
    if (matchAudio) {
      try {
        matchAudio.onended = null;
      } catch (_) {}
    }
    var a = new Audio(src);
    matchAudio = a;
    a.play().catch(function () {});
  }

  var playingLeft = null;

  function playPromptAudio(src, leftIndex) {
    if (playingLeft === leftIndex && promptAudio && !promptAudio.paused) {
      stopPromptAudio();
      playingLeft = null;
      return;
    }
    stopPromptAudio();
    if (!src) return;
    var a = new Audio(src);
    promptAudio = a;
    playingLeft = leftIndex;
    var btn = app.querySelector('.mc-play[data-i="' + leftIndex + '"]');
    if (btn) btn.classList.add("playing");
    a.play().catch(function () {
      if (btn) btn.classList.remove("playing");
      playingLeft = null;
    });
    a.onended = function () {
      if (btn) btn.classList.remove("playing");
      if (playingLeft === leftIndex) playingLeft = null;
      promptAudio = null;
    };
  }

  function playAudioFor(leftIndex) {
    var id = leftOrder[leftIndex];
    var c = byId(id);
    if (!c) return;
    playPromptAudio(c.audio, leftIndex);
  }

  function startMode(mi) {
    getSfxCtx();
    if (window.LAFinish) LAFinish.startTimer();
    modeIndex = mi;
    modeCorrect = 0;
    wrongCount = 0;
    lives = 3;
    phase = "play";
    startSet(0);
  }

  function startSet(si) {
    // Do NOT stop matchAudio — last match sound may still be playing
    stopPromptAudio();
    setIndex = si;
    var ids = SETS[setIndex].slice();
    leftOrder = shuffle(ids);
    rightOrder = shuffle(ids);
    selectedLeft = null;
    locked = {};
    matches = {};
    busy = false;
    phase = "play";
    render();
  }

  function selectLeft(i) {
    if (busy || locked[i] != null) return;
    selectedLeft = i;
    var mode = MODES[modeIndex];
    if (mode.left === "audio") playAudioFor(i);
    renderPlaySelection();
  }


  function spawnParticles(cardEl) {
    if (!cardEl) return;
    var colors = ["#7c6af7", "#4caf50", "#ff9800", "#e91e63", "#2196f3", "#ffeb3b"];
    var container = document.createElement("div");
    container.className = "mc-particles";
    cardEl.appendChild(container);
    for (var i = 0; i < 10; i++) {
      var p = document.createElement("div");
      p.className = "mc-particle";
      var angle = (i / 10) * Math.PI * 2 + (Math.random() - 0.5) * 0.4;
      var dist = 28 + Math.random() * 36;
      p.style.setProperty("--tx", Math.cos(angle) * dist + "px");
      p.style.setProperty("--ty", Math.sin(angle) * dist + "px");
      p.style.background = colors[i % colors.length];
      var size = 5 + Math.random() * 5;
      p.style.width = size + "px";
      p.style.height = size + "px";
      p.style.animationDelay = Math.random() * 0.06 + "s";
      container.appendChild(p);
    }
    setTimeout(function () {
      try {
        container.remove();
      } catch (_) {}
    }, 800);
  }


  function heartsHtml() {
    var h = '<div class="mc-hearts" id="mc-hearts" aria-label="Lives">';
    for (var i = 0; i < 3; i++) {
      if (i < lives) {
        h += '<span class="mc-heart is-full" data-i="' + i + '">♥</span>';
      } else {
        h += '<span class="mc-heart is-broken" data-i="' + i + '">♡</span>';
      }
    }
    return h + "</div>";
  }

  function renderHearts() {
    var root = document.getElementById("mc-hearts");
    if (!root) return;
    var nodes = root.querySelectorAll(".mc-heart");
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      el.classList.remove("is-full", "is-broken", "is-breaking");
      if (i < lives) {
        el.classList.add("is-full");
        el.textContent = "♥";
      } else {
        el.classList.add("is-broken");
        el.textContent = "♡";
      }
    }
  }

  function breakHeart(done) {
    wrongCount++;
    if (lives <= 0) {
      if (done) done();
      return;
    }
    var loseIndex = lives - 1;
    lives -= 1;
    var root = document.getElementById("mc-hearts");
    var el = root ? root.querySelector('.mc-heart[data-i="' + loseIndex + '"]') : null;
    if (el) {
      el.classList.remove("is-full");
      el.classList.add("is-breaking");
      el.textContent = "♥";
      setTimeout(function () {
        el.classList.remove("is-breaking");
        el.classList.add("is-broken");
        el.textContent = "♡";
        if (done) done();
      }, 480);
    } else {
      renderHearts();
      if (done) done();
    }
  }

  function selectRight(rightId) {
    if (busy || selectedLeft == null) return;
    if (Object.keys(locked).some(function (li) { return matches[li] === rightId; })) return;

    var leftId = leftOrder[selectedLeft];
    var leftEl = app.querySelector('.mc-left-item[data-i="' + selectedLeft + '"]');
    var rightEl = app.querySelector('.mc-right-item[data-id="' + rightId + '"]');

    if (leftId !== rightId) {
      sfxBad();
      busy = true;
      if (leftEl) leftEl.classList.add("is-wrong");
      if (rightEl) rightEl.classList.add("is-wrong");
      setTimeout(function () {
        if (leftEl) leftEl.classList.remove("is-wrong");
        if (rightEl) rightEl.classList.remove("is-wrong");
      }, 500);
      breakHeart(function () {
        busy = false; // mistakes no longer end the game; stars come from accuracy
      });
      return;
    }

    // correct — update in place (no full re-render = no flicker)
    busy = true;
    sfxOk();
    var leftIdx = selectedLeft;
    locked[leftIdx] = rightId;
    matches[leftIdx] = rightId;
    modeCorrect += 1;

    var item = byId(leftId);
    // Words → Pictures: play audio after a match (do not cut on next set)
    if (MODES[modeIndex].id === "word-pic" && item) {
      playMatchAudio(item.audio);
    }

    // Mark tiles without rebuilding the board + matchPop + particles
    if (leftEl) {
      leftEl.classList.remove("is-selected", "is-wrong");
      leftEl.classList.add("is-correct");
      var playBtn = leftEl.querySelector(".mc-play");
      if (playBtn) playBtn.disabled = true;
      spawnParticles(leftEl);
    }
    if (rightEl) {
      rightEl.classList.remove("is-wrong");
      rightEl.classList.add("is-correct", "is-used");
      rightEl.disabled = true;
      spawnParticles(rightEl);
    }

    // Clear selection highlight on all left items
    app.querySelectorAll(".mc-left-item.is-selected").forEach(function (el) {
      el.classList.remove("is-selected");
    });
    selectedLeft = null;

    // Progress text only
    var prog = document.getElementById("mc-progress");
    if (prog) {
      prog.textContent =
        "Set " + (setIndex + 1) + "/" + SETS.length + " · " + correctCount() + "/" + setSize();
    }

    if (allMatched()) {
      setTimeout(function () {
        var half = Math.floor(SETS.length / 2) - 1;
        if (setIndex === half && setIndex < SETS.length - 1) {
          // halfway: pop-up, then continue with the next set
          if (window.ArcadeFX) ArcadeFX.cheer(0, 2, "Halfway there — " + (half + 1) + " of " + SETS.length + " sets done");
          setTimeout(function () { startSet(setIndex + 1); }, 1500);
        } else if (setIndex < SETS.length - 1) {
          startSet(setIndex + 1);
        } else {
          if (window.ArcadeFX) ArcadeFX.cheer(1, 2, "All " + SETS.length + " sets done");
          finishMode();
        }
      }, 700);
    } else {
      busy = false;
    }
  }

  function calcStars() {
    // Stars come from accuracy: correct matches / all match attempts
    var attempts = modeCorrect + wrongCount;
    if (modeCorrect < totalPairs() || attempts === 0) return 0;
    var acc = modeCorrect / attempts;
    return acc >= 0.9 ? 3 : acc >= 0.7 ? 2 : 1;
  }

  function finishMode() {
    phase = "done";
    stopPromptAudio();
    busy = true;
    var total = totalPairs();
    // Stars = hearts remaining (0–3)
    var stars = calcStars();

    if (window.LAFinish) {
      try {
        var timeMs = LAFinish.stopTimer();
        LAFinish.show({
          gameId: GAME_ID,
          score: modeCorrect,
          total: total,
          stars: stars,
          accuracy: Math.round((modeCorrect / Math.max(1, modeCorrect + wrongCount)) * 100),
          timeMs: timeMs,
          onAgain: function () {
            startMode(modeIndex);
          },
          onModes: function () {
            phase = "menu";
            render();
          },
          backHref: "../"
        });
        return;
      } catch (e) {
        console.warn("LAFinish", e);
      }
    }

    if (window.LAStars) {
      try {
        LAStars.recordPlay(GAME_ID);
        if (stars > 0) LAStars.save(GAME_ID, stars);
      } catch (_) {}
    }

    render();
  }

  function leftCell(id, i, kind) {
    var c = byId(id);
    var isLocked = locked[i] != null;
    var sel = selectedLeft === i ? " is-selected" : "";
    var ok = isLocked ? " is-correct" : "";

    if (kind === "audio") {
      return (
        '<div class="mc-left-item mc-audio-cell' + ok + sel + '" data-i="' + i + '">' +
        '<button type="button" class="mc-play" data-i="' + i + '" aria-label="Play ' + escapeAttr(c.label) + '"' +
        (isLocked ? " disabled" : "") + ">" +
        '<span class="wave"></span><span class="wave"></span><span class="wave"></span>' +
        '<svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>' +
        '<div class="eq"><span></span><span></span><span></span><span></span></div>' +
        "</button></div>"
      );
    }

    // word
    return (
      '<div class="mc-left-item mc-word-left' + ok + sel + '" data-i="' + i + '">' +
      '<span class="mc-word-label">' + escapeHtml(c.label) + "</span></div>"
    );
  }

  function rightCell(id, kind) {
    var c = byId(id);
    var used = Object.keys(locked).some(function (li) {
      return matches[li] === id;
    });
    var ok = used ? " is-correct is-used" : "";

    if (kind === "picture") {
      return (
        '<button type="button" class="mc-right-item mc-pic' + ok + '" data-id="' + id + '"' +
        (used ? " disabled" : "") + ' aria-label="' + escapeAttr(c.label) + '">' +
        '<img src="' + c.image + '" alt="" draggable="false" loading="lazy" />' +
        "</button>"
      );
    }

    // word
    return (
      '<button type="button" class="mc-right-item mc-word' + ok + '" data-id="' + id + '"' +
      (used ? " disabled" : "") + ">" +
      '<span class="mc-word-label">' + escapeHtml(c.label) + "</span></button>"
    );
  }

  function renderPlaySelection() {
    app.querySelectorAll(".mc-left-item").forEach(function (el) {
      el.classList.toggle("is-selected", +el.dataset.i === selectedLeft);
    });
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function escapeAttr(s) {
    return escapeHtml(s).replace(/'/g, "&#39;");
  }

  function render() {
    if (phase === "menu") {
      stopPromptAudio();
      app.innerHTML =
        '<header class="mc-topbar">' +
        '<a class="mc-back" href="../" aria-label="Back">←</a>' +
        '<span class="mc-title">Food Match</span>' +
        '<span class="mc-badge">5A</span></header>' +
        '<section class="mc-start">' +
        '<div class="mc-hero" aria-hidden="true">🍽️</div>' +
        "<h1>Food Match</h1>" +
        '<p class="mc-desc">Choose a mode · ' + totalPairs() + ' foods &amp; drinks (' + SETS.length + ' sets)</p>' +
        '<div class="mc-mode-list">' +
        MODES.map(function (m, i) {
          return (
            '<button type="button" class="mc-mode-card mc-mode-btn" data-mode="' + i + '">' +
            '<span class="mc-mode-num">' + (i + 1) + "</span>" +
            "<div><strong>" + escapeHtml(m.title) + "</strong><p>" + escapeHtml(m.tip) + "</p></div>" +
            "</button>"
          );
        }).join("") +
        "</div></section>";

      app.querySelectorAll(".mc-mode-btn").forEach(function (btn) {
        btn.onclick = function () {
          startMode(+btn.dataset.mode);
        };
      });
      return;
    }

    if (phase === "done") {
      var total = totalPairs();
      var stars = calcStars();
      app.innerHTML =
        '<header class="mc-topbar">' +
        '<a class="mc-back" href="../" aria-label="Back">←</a>' +
        '<span class="mc-title">Food Match</span>' +
        '<span class="mc-badge">Done</span></header>' +
        '<section class="mc-done">' +
        '<div class="mc-trophy">' + (stars === 3 ? "🏆" : stars >= 1 ? "🌟" : "💪") + "</div>" +
        "<h1>" + (stars === 3 ? "Perfect!" : "Well done!") + "</h1>" +
        "<p>You matched <strong>" + modeCorrect + " / " + total + "</strong> pairs.</p>" +
        '<button type="button" class="mc-btn" id="fb-again">Play again</button>' +
        '<button type="button" class="mc-btn secondary" id="fb-menu">All modes</button>' +
        "</section>";
      document.getElementById("fb-again").onclick = function () {
        startMode(modeIndex);
      };
      document.getElementById("fb-menu").onclick = function () {
        phase = "menu";
        render();
      };
      return;
    }

    // play
    var mode = MODES[modeIndex];
    var n = setSize();
    var left = leftOrder
      .map(function (id, i) {
        return leftCell(id, i, mode.left);
      })
      .join("");
    var right = rightOrder
      .map(function (id) {
        return rightCell(id, mode.right);
      })
      .join("");

    app.innerHTML =
      '<header class="mc-topbar">' +
      '<a class="mc-back" href="../" aria-label="Back">←</a>' +
      '<span class="mc-title">' + escapeHtml(mode.title) + " · Set " + (setIndex + 1) + "/4</span>" +
      heartsHtml() +
      '<span class="mc-progress" id="mc-progress">Set ' +
      (setIndex + 1) +
      "/4 · " +
      correctCount() +
      "/" +
      n +
      "</span></header>" +
      '<p class="mc-instruction" id="mc-hint">' + escapeHtml(mode.tip) + "</p>" +
      '<div class="mc-board mc-set-' + n + '">' +
      '<div class="mc-col mc-col-left">' + left + "</div>" +
      '<div class="mc-col mc-col-right">' + right + "</div>" +
      "</div>" +
      '<div class="mc-actions">' +
      '<button type="button" class="mc-btn secondary" id="mc-reset">Reset round</button>' +
      "</div>";

    app.querySelectorAll(".mc-left-item").forEach(function (el) {
      el.onclick = function () {
        selectLeft(+el.dataset.i);
      };
    });
    app.querySelectorAll(".mc-play").forEach(function (btn) {
      btn.onclick = function (e) {
        e.stopPropagation();
        selectLeft(+btn.dataset.i);
      };
    });
    app.querySelectorAll(".mc-right-item").forEach(function (btn) {
      btn.onclick = function () {
        selectRight(btn.dataset.id);
      };
    });
    document.getElementById("mc-reset").onclick = function () {
      startSet(setIndex);
    };
  }

  // Preload images
  ITEMS.forEach(function (it) {
    var img = new Image();
    img.src = it.image;
  });

  render();
})();
