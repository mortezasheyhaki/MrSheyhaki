/* ===== Arcade FX: progress bar, combo, milestone celebration ===== */
(function () {
  if (window.ArcadeFX) return;
  var streak = 0, best = 0, count = 0, lastPct = 0, ctx = null;
  var CHEERS = [["🌟","Awesome!","10 correct answers!"],["🚀","Superstar!","20 correct — unstoppable!"],["👑","Legend!","30 correct — the best of the best!"]];
  function tone(f, d, type, v, when) {
    try {
      if (!ctx) { var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return; ctx = new AC(); }
      if (ctx.state === "suspended") ctx.resume();
      var t = ctx.currentTime + (when || 0), o = ctx.createOscillator(), g = ctx.createGain();
      o.type = type || "sine"; o.frequency.value = f;
      g.gain.setValueAtTime(v || 0.09, t); g.gain.exponentialRampToValueAtTime(0.001, t + d);
      o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + d + 0.03);
    } catch (e) {}
  }
  function label(n) { return n >= 10 ? "UNSTOPPABLE" : n >= 7 ? "ON FIRE" : n >= 5 ? "HOT STREAK" : n >= 3 ? "NICE" : ""; }
  function chip() {
    var el = document.getElementById("afx-combo");
    if (!el) { el = document.createElement("div"); el.id = "afx-combo"; el.className = "afx-combo"; document.body.appendChild(el); }
    return el;
  }
  function place(el) {
    el = el || document.getElementById("afx-combo");
    var app = (document.getElementById("game-app") || document.getElementById("app"));
    if (!el || !app) return;
    var a = app.querySelector(".afx-bar") || app.querySelector("header") || app.firstElementChild;
    if (!a) return;
    if (a.offsetParent === null) a = app;
    var r = a.getBoundingClientRect();
    el.style.right = Math.max(8, document.documentElement.clientWidth - r.right) + "px";
    el.style.top = Math.max(8, a === app ? r.top + 64 : r.bottom + 8) + "px";
  }
  function showCombo() {
    var el = chip(); place(el);
    el.className = "afx-combo is-on" + (streak >= 5 ? " is-hot" : "");
    el.innerHTML = '<span class="afx-fire">🔥</span> x' + streak + " <em>" + label(streak) + "</em>";
    void el.offsetWidth; el.classList.add("is-bump");
  }
  function celebrate(n) {
    var c = CHEERS[Math.min(Math.floor(n / 10) - 1, 2)];
    [523, 659, 784, 1047, 1319].forEach(function (f, i) { tone(f, 0.22, "triangle", 0.1, i * 0.09); });
    tone(1568, 0.6, "sine", 0.08, 0.5);
    var ov = document.createElement("div"); ov.className = "afx-burst";
    var cols = ["#f59e0b", "#ec4899", "#8b5cf6", "#22c55e", "#3b82f6", "#ef4444"], h = "";
    for (var i = 0; i < 44; i++) h += '<i style="left:' + Math.random() * 100 + "%;background:" + cols[i % 6] + ";animation-delay:" + (Math.random() * 0.35).toFixed(2) + "s;animation-duration:" + (1.3 + Math.random() * 0.9).toFixed(2) + 's"></i>';
    ov.innerHTML = h + '<div class="afx-card"><div class="afx-emoji">' + c[0] + '</div><div class="afx-title">' + c[1] + '</div><div class="afx-sub">' + c[2] + "</div></div>";
    document.body.appendChild(ov);
    setTimeout(function () { ov.classList.add("is-out"); }, 1900);
    setTimeout(function () { if (ov.parentNode) ov.parentNode.removeChild(ov); }, 2300);
  }
  function hookRestart() {
    var L = window.LAFinish;
    if (L && L.startTimer && !L.__afx) { var st = L.startTimer; L.__afx = 1; L.startTimer = function () { api.reset(); return st.apply(this, arguments); }; }
  }
  var api = window.ArcadeFX = {
    ok: function () {
      var nw = Date.now(); if (nw - (api._o || 0) < 90) return; api._o = nw;
      hookRestart(); streak++; count++; if (streak > best) best = streak;
      if (streak >= 2) { var b = 660 * Math.pow(1.0595, Math.min(streak, 12)); tone(b, 0.09, "triangle", 0.08, 0); tone(b * 1.5, 0.14, "triangle", 0.07, 0.07); showCombo(); }
      if (count % 10 === 0) setTimeout(function () { celebrate(count); }, 250);
    },
    bad: function () {
      var nw = Date.now(); if (nw - (api._b || 0) < 90) return; api._b = nw;
      hookRestart();
      if (streak >= 3) { tone(300, 0.12, "sawtooth", 0.05, 0); tone(200, 0.2, "sawtooth", 0.05, 0.09); }
      if (streak >= 2) { var el = chip(); el.className = "afx-combo is-lost"; el.textContent = "Combo lost"; setTimeout(function () { el.className = "afx-combo"; }, 1200); }
      streak = 0;
    },
    reset: function () { streak = 0; best = 0; count = 0; lastPct = 0; var el = document.getElementById("afx-combo"); if (el) el.className = "afx-combo"; }
  };
  function sync() {
    var app = (document.getElementById("game-app") || document.getElementById("app")); if (!app) return;
    place();
    var bar = app.querySelector(".afx-bar");
    if (bar && bar.offsetParent === null) { bar.parentNode.removeChild(bar); bar = null; }
    var badge = null, hasBar = false, els = app.querySelectorAll('[class*="-badge"],[class*="-progress"]');
    for (var i = 0; i < els.length; i++) {
      var t = els[i].textContent.trim(); if (els[i].offsetParent === null) continue;
      if (/^\d+\s*\/\s*\d+$/.test(t)) { if (!badge) badge = els[i]; }
      else if (!t && /progress/.test(els[i].className) && !els[i].classList.contains("afx-bar")) hasBar = true;
    }
    if (!badge || hasBar) return;
    var m = badge.textContent.trim().match(/^(\d+)\s*\/\s*(\d+)$/), pct = Math.min(100, Math.round(m[1] / m[2] * 100));
    if (!bar) {
      var host = badge.closest("header") || badge.parentElement;
      bar = document.createElement("div"); bar.className = "afx-bar"; bar.innerHTML = '<i style="width:' + lastPct + '%"></i>';
      host.parentNode.insertBefore(bar, host.nextSibling);
    }
    var fill = bar.firstChild; lastPct = pct;
    requestAnimationFrame(function () { requestAnimationFrame(function () { fill.style.width = pct + "%"; }); });
  }
  var q = 0;
  function start() {
    var app = (document.getElementById("game-app") || document.getElementById("app")); if (!app) return;
    new MutationObserver(function () { if (q) return; q = requestAnimationFrame(function () { q = 0; sync(); }); }).observe(app, { childList: true, subtree: true, characterData: true });
    window.addEventListener("resize", function () { place(); });
    window.addEventListener("scroll", function () { place(); }, { passive: true });
    sync();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();

/* Food Type – picture + listen + type · AEF Starter Unit 5A */
(function () {
  "use strict";

  

/* === Shared UI sound effects (Web Audio) === */
(function () {
  if (window.__laUiSfx) return;
  var ctx = null;
  function getCtx() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === "suspended") ctx.resume().catch(function () {});
    return ctx;
  }
  function tone(freq, dur, type, vol, when) {
    var c = getCtx();
    if (!c) return;
    var t0 = (when || 0) + c.currentTime;
    var osc = c.createOscillator();
    var gain = c.createGain();
    osc.type = type || "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(vol || 0.12, t0);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    osc.connect(gain);
    gain.connect(c.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }
  function sfxTap() { tone(520, 0.06, "triangle", 0.08); }
  function sfxCorrect() { window.ArcadeFX && ArcadeFX.ok();
    tone(523, 0.1, "sine", 0.12, 0);
    tone(659, 0.12, "sine", 0.12, 0.08);
    tone(784, 0.18, "sine", 0.1, 0.16);
  }
  function sfxWrong() { window.ArcadeFX && ArcadeFX.bad();
    tone(220, 0.14, "sawtooth", 0.07, 0);
    tone(180, 0.18, "sawtooth", 0.06, 0.1);
  }
  function sfxCelebrate() {
    [523, 659, 784, 1047].forEach(function (f, i) { tone(f, 0.15, "sine", 0.1, i * 0.07); });
  }
  window.__laUiSfx = { tap: sfxTap, correct: sfxCorrect, wrong: sfxWrong, celebrate: sfxCelebrate };
  window.sfxTap = sfxTap; window.sfxCorrect = sfxCorrect; window.sfxWrong = sfxWrong; window.sfxCelebrate = sfxCelebrate;
  var lastAt = 0, lastKind = "";
  function fire(kind, fn) {
    var now = Date.now();
    if (kind === lastKind && now - lastAt < 80) return;
    lastKind = kind; lastAt = now;
    try { fn(); } catch (e) {}
  }
  try {
    var origAdd = DOMTokenList.prototype.add;
    DOMTokenList.prototype.add = function () {
      var tokens = Array.prototype.slice.call(arguments);
      var r = origAdd.apply(this, tokens);
      if (tokens.indexOf("correct") >= 0 || tokens.indexOf("is-correct") >= 0 || tokens.indexOf("picked-ok") >= 0) fire("correct", sfxCorrect);
      else if (tokens.indexOf("wrong") >= 0 || tokens.indexOf("is-wrong") >= 0) fire("wrong", sfxWrong);
      return r;
    };
  } catch (e) {}
})();

var GAME_ID = "starter-5a-food-type";
  var CDN = "https://cdn.imgurl.ir/uploads/";

  var WORDS = [
    { id: "orange-juice", label: "orange juice", image: CDN + "y474569_orange_juicve.png", audio: CDN + "m430952_orange_juice.mp3" },
    { id: "water", label: "water", image: CDN + "l28997_water.png", audio: CDN + "n0647_water_2.mp3" },
    { id: "milk", label: "milk", image: CDN + "o371209_milk.png", audio: CDN + "u575098_milk.mp3" },
    { id: "tea", label: "tea", image: CDN + "m857428_tea.png", audio: CDN + "i64279_tea.mp3" },
    { id: "coffee", label: "coffee", image: CDN + "d27147_coffee.png", audio: CDN + "p495679_coffee_2.mp3" },
    { id: "chocolate", label: "chocolate", image: CDN + "y725106_chocolate.png", audio: CDN + "d5050_chocolate.mp3" },
    { id: "cereal", label: "cereal", image: CDN + "w365421_cereal.png", audio: CDN + "i58138_cereal.mp3" },
    { id: "sandwich", label: "a sandwich", image: CDN + "g593040_a_sandwich.png", audio: CDN + "d503380_a_sandwich.mp3" },
    { id: "sugar", label: "sugar", image: CDN + "t65307_sugar.png", audio: CDN + "i330159_sugar.mp3" },
    { id: "cheese", label: "cheese", image: CDN + "186291_cheese.png", audio: CDN + "s1383_cheese.mp3" },
    { id: "butter", label: "butter", image: CDN + "q390114_butter.png", audio: CDN + "z611617_butter.mp3" },
    { id: "bread", label: "bread", image: CDN + "q54444_bread.png", audio: CDN + "l534951_bread.mp3" },
    { id: "fruit", label: "fruit", image: CDN + "g252280_fruit.png", audio: CDN + "l707897_fruit.mp3" },
    { id: "salad", label: "salad", image: CDN + "r6371_salad.png", audio: CDN + "p30139_salad.mp3" },
    { id: "potatoes", label: "potatoes", image: CDN + "w96375_potatoes.png", audio: CDN + "g067013_potatoes.mp3" },
    { id: "vegetables", label: "vegetables", image: CDN + "j10452_vegetables.png", audio: CDN + "n05883_vegetables_2.mp3" },
    { id: "yogurt", label: "yogurt", image: CDN + "b8972_yogurt.png", audio: CDN + "t99484_yogurt.mp3" },
    { id: "eggs", label: "eggs", image: CDN + "n773101_eggs.png", audio: CDN + "n595148_eggs.mp3" },
    { id: "rice", label: "rice", image: CDN + "y840090_rice.png", audio: CDN + "y43521_rice.mp3" },
    { id: "pasta", label: "pasta", image: CDN + "r41660_pasta.png", audio: CDN + "a446167_pasta.mp3" },
    { id: "meat", label: "meat", image: CDN + "x930201_m.png", audio: CDN + "d13610_m.mp3" },
    { id: "fish", label: "fish", image: CDN + "z779185_fish.png", audio: CDN + "i64676_fish.mp3" }
  ];

  var TOTAL = WORDS.length;
  var app = document.getElementById("game-app");
  if (!app) return;

  var phase = "start";
  var deck = [];
  var index = 0;
  var target = null;
  var locked = false;
  var lives = 3;
  var score = 0;
  var currentAudio = null;
  var sfxCtx = null;

  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i];
      a[i] = a[j];
      a[j] = t;
    }
    return a;
  }

  function norm(s) {
    return String(s || "")
      .trim()
      .toLowerCase()
      .replace(/\s+/g, " ");
  }

  function getSfxCtx() {
    if (!sfxCtx) {
      try {
        sfxCtx = new (window.AudioContext || window.webkitAudioContext)();
      } catch (e) {
        return null;
      }
    }
    if (sfxCtx.state === "suspended") sfxCtx.resume().catch(function () {});
    return sfxCtx;
  }

  function tone(freq, start, dur, type, gain) {
    var ctx = getSfxCtx();
    if (!ctx) return;
    var o = ctx.createOscillator();
    var g = ctx.createGain();
    o.type = type || "sine";
    o.frequency.setValueAtTime(freq, start);
    g.gain.setValueAtTime(0.0001, start);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, gain || 0.1), start + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
    o.connect(g);
    g.connect(ctx.destination);
    o.start(start);
    o.stop(start + dur + 0.02);
  }

  function sfxOk() { window.ArcadeFX && ArcadeFX.ok();
    try {
      if (window.LASfx && LASfx.correct) LASfx.correct();
    } catch (_) {}
    var ctx = getSfxCtx();
    if (!ctx) return;
    var t = ctx.currentTime;
    tone(523.25, t, 0.09, "triangle", 0.12);
    tone(659.25, t + 0.07, 0.1, "triangle", 0.12);
    tone(783.99, t + 0.14, 0.14, "sine", 0.1);
  }

  function sfxBad() { window.ArcadeFX && ArcadeFX.bad();
    try {
      if (window.LASfx && LASfx.wrong) LASfx.wrong();
    } catch (_) {}
    var ctx = getSfxCtx();
    if (!ctx) return;
    tone(200, ctx.currentTime, 0.12, "sawtooth", 0.06);
  }

  function stopAudio() {
    if (currentAudio) {
      try {
        currentAudio.pause();
      } catch (_) {}
      currentAudio = null;
    }
    app.querySelectorAll(".fu-play.playing").forEach(function (b) {
      b.classList.remove("playing");
    });
  }

  function playAudio() {
    if (!target || !target.audio) return;
    stopAudio();
    var a = new Audio(target.audio);
    currentAudio = a;
    var btn = app.querySelector(".fu-play");
    if (btn) btn.classList.add("playing");
    a.play().catch(function () {
      if (btn) btn.classList.remove("playing");
    });
    a.onended = function () {
      if (btn) btn.classList.remove("playing");
      currentAudio = null;
    };
  }

  function heartsHtml() {
    var h = '<div class="fu-hearts" id="fu-hearts" aria-label="Lives">';
    for (var i = 0; i < 3; i++) {
      if (i < lives) h += '<span class="fu-heart is-full" data-i="' + i + '">♥</span>';
      else h += '<span class="fu-heart is-broken" data-i="' + i + '">♡</span>';
    }
    return h + "</div>";
  }

  function breakHeart(done) {
    if (lives <= 0) {
      if (done) done();
      return;
    }
    var loseIndex = lives - 1;
    lives -= 1;
    var el = app.querySelector('.fu-heart[data-i="' + loseIndex + '"]');
    if (el) {
      el.classList.remove("is-full");
      el.classList.add("is-breaking");
      el.textContent = "♥";
      setTimeout(function () {
        el.classList.remove("is-breaking");
        el.classList.add("is-broken");
        el.textContent = "♡";
        if (done) done();
      }, 480);
    } else if (done) done();
  }

  function startGame() {
    getSfxCtx();
    if (window.LAFinish) LAFinish.startTimer();
    deck = shuffle(WORDS);
    index = 0;
    score = 0;
    lives = 3;
    phase = "play";
    startRound();
  }

  function startRound() {
    if (index >= deck.length || lives <= 0) {
      finishGame();
      return;
    }
    locked = false;
    target = deck[index];
    stopAudio();
    render();
    setTimeout(function () {
      if (!locked && phase === "play") playAudio();
      var input = document.getElementById("fu-input");
      if (input) {
        try {
          input.focus();
        } catch (_) {}
      }
    }, 280);
  }

  function checkAnswer() {
    if (locked) return;
    var input = document.getElementById("fu-input");
    if (!input) return;
    var val = input.value;
    if (!norm(val)) {
      input.focus();
      return;
    }

    var ok = norm(val) === norm(target.label);
    // Accept "sandwich" for "a sandwich"? User said a sandwich separately - require full phrase
    // Also accept without article for sandwich? Stick to exact label match normalized.

    if (!ok) { try{sfxWrong();}catch(e){}
      sfxBad();
      locked = true;
      input.classList.add("bad");
      var fb = document.getElementById("fu-fb");
      if (fb) {
        fb.textContent = "Not quite — try again.";
        fb.className = "lw-fb bad";
      }
      breakHeart(function () {
        if (lives <= 0) {
          setTimeout(finishGame, 500);
          return;
        }
        setTimeout(function () {
          locked = false;
          input.classList.remove("bad");
          input.value = "";
          input.focus();
          if (fb) {
            fb.textContent = "";
            fb.className = "lw-fb";
          }
        }, 400);
      });
      return;
    }

    locked = true;
    stopAudio();
    sfxOk();
    score += 1;
    input.disabled = true;
    input.classList.remove("bad");
    input.classList.add("ok");
    input.value = target.label;
    var fb2 = document.getElementById("fu-fb");
    if (fb2) {
      fb2.innerHTML = "✓ <strong>" + target.label + "</strong>";
      fb2.className = "lw-fb ok";
    }
    setTimeout(function () {
      index += 1;
      startRound();
    }, 900);
  }

  function clearInput() {
    if (locked) return;
    var input = document.getElementById("fu-input");
    if (!input) return;
    input.value = "";
    input.classList.remove("ok", "bad");
    input.focus();
    var fb = document.getElementById("fu-fb");
    if (fb) {
      fb.textContent = "";
      fb.className = "lw-fb";
    }
  }

  function finishGame() {
    stopAudio();
    phase = "done";
    var stars = Math.max(0, Math.min(3, lives));
    if (window.LAFinish) {
      try {
        var timeMs = LAFinish.stopTimer();
        LAFinish.show({
          gameId: GAME_ID,
          score: score,
          total: TOTAL,
          stars: stars,
          timeMs: timeMs,
          onAgain: startGame,
          onModes: function () {
            phase = "start";
            render();
          },
          backHref: "../"
        });
        return;
      } catch (e) {
        console.warn(e);
      }
    }
    if (window.LAStars) {
      try {
        LAStars.recordPlay(GAME_ID);
        if (stars > 0) LAStars.save(GAME_ID, stars);
      } catch (_) {}
    }
    render();
  }

  function render() {
    if (phase === "start") {
      stopAudio();
      app.innerHTML =
        '<header class="lw-topbar">' +
        '<a class="lw-back" href="../" aria-label="Back">←</a>' +
        '<span class="lw-title">Food Type</span>' +
        '<span class="lw-badge">5A</span></header>' +
        '<section class="lw-start">' +
        '<div class="lw-hero" aria-hidden="true">⌨️</div>' +
        "<h1>Food Type</h1>" +
        '<p class="lw-sub">Look, listen, and type ' +
        TOTAL +
        " food words</p>" +
        '<button type="button" class="lw-btn" id="fu-start">Start</button>' +
        "</section>";
      document.getElementById("fu-start").onclick = startGame;
      return;
    }

    if (phase === "done") {
      var stars = Math.max(0, Math.min(3, lives));
      app.innerHTML =
        '<header class="lw-topbar">' +
        '<a class="lw-back" href="../" aria-label="Back">←</a>' +
        '<span class="lw-title">Food Type</span>' +
        '<span class="lw-badge">Done</span></header>' +
        '<section class="lw-start">' +
        "<h1>" +
        (stars === 3 ? "Perfect!" : stars > 0 ? "Well done!" : "Keep practicing!") +
        "</h1>" +
        '<p class="lw-sub">You typed <strong>' +
        score +
        "</strong> of " +
        TOTAL +
        "</p>" +
        '<button type="button" class="lw-btn" id="fu-again">Play again</button>' +
        "</section>";
      document.getElementById("fu-again").onclick = startGame;
      return;
    }

    var pct = Math.round((index / TOTAL) * 100);
    app.innerHTML =
      '<header class="lw-topbar">' +
      '<a class="lw-back" href="../" aria-label="Back">←</a>' +
      '<span class="lw-title">Food Type</span>' +
      heartsHtml() +
      '<span class="lw-badge">' +
      (index + 1) +
      " / " +
      TOTAL +
      "</span></header>" +
      '<div class="lw-progress"><div class="lw-progress-fill" style="width:' +
      pct +
      '%"></div></div>' +
      '<div class="fu-card">' +
      '<div class="fu-pic-wrap"><img class="fu-pic" src="' +
      target.image +
      '" alt="" draggable="false" /></div>' +
      '<div class="fu-listen">' +
      '<button type="button" class="fu-play" id="fu-play" aria-label="Play audio">' +
      '<span class="wave"></span><span class="wave"></span><span class="wave"></span>' +
      '<svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>' +
      '<div class="eq"><span></span><span></span><span></span><span></span></div>' +
      "</button>" +
      "<span>Listen, then type the word</span>" +
      "</div>" +
      '<input type="text" class="fu-input" id="fu-input" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Type here…" />' +
      '<div class="fu-actions">' +
      '<button type="button" class="lw-btn secondary" id="fu-clear">Clear</button>' +
      '<button type="button" class="lw-btn" id="fu-check">Check ✓</button>' +
      "</div>" +
      '<div class="lw-fb" id="fu-fb" aria-live="polite"></div>' +
      "</div>";

    document.getElementById("fu-play").onclick = playAudio;
    document.getElementById("fu-clear").onclick = clearInput;
    document.getElementById("fu-check").onclick = checkAnswer;
    var input = document.getElementById("fu-input");
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter") {
        e.preventDefault();
        checkAnswer();
      }
    });
  }

  WORDS.forEach(function (w) {
    var img = new Image();
    img.src = w.image;
  });

  render();
})();
